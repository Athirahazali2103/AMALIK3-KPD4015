<?php 
$connection=mysqli_connect("localhost", "root","","barang") or die("failed...");
//$connect ditukar kepada $connection , localhost:33006 ditukar kepada localhost password dibuang
?>
