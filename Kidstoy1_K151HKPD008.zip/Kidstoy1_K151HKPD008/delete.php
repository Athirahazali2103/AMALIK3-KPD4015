Delete.php
<?php
include 'config.php'; 
	$kod_produk =$_GET['kod_produk'];// sending query
	$delete= mysqli_query($connection, "DELETE FROM jadualmainan WHERE kod_produk = '$kod_produk'") or die (mysqli_error()) ;
	//menukar $connect kepada $connection dan $jadual_item ke jadualmainana serta menambah or die (mysqli_error())
	header("Location: index.php");
?>
