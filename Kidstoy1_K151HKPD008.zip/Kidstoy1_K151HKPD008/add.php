<html>
<body>
<?php
include('config.php');


if(isset($_POST['submit']))
{

$kod_produk=($_POST['kod_produk']);
$nama_produk=($_POST['nama_produk']);
$harga=($_POST['harga']);
$kuantiti=($_POST['kuantiti']);


$insert = mysqli_query($connection, "INSERT INTO jadualmainan VALUES ('$kod_produk','$nama_produk','$harga','$kuantiti')");
//$connect ditukar kepada $connection
	header("location:index.php");
}
?>


<center>
<fieldset style="width:500px;">
<h4>TAMBAH REKOD MAINAN</h4>

<form method="post" action="">
KOD PRODUK: <input type="text" name="kod_produk"><br><br>
NAMA PRODUK: <input type="text" name="nama_produk"><br><br>
HARGA : <input type="text" name="harga"><br><br>
KUANTITI : <input type="text" name="kuantiti"><br><br>
<br>
<input type="submit" name="submit">
</form>

</fieldset>
</center>
</body>
</html>